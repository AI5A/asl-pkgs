/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "1f44d668e816"
#define BUILD_KERNEL "5.15.0-1022-azure"
#define BUILD_MACHINE "x86_64"
#define BUILD_OS "Linux"
#define BUILD_DATE "2022-11-10 06:24:46 UTC"
#define BUILD_USER ""

