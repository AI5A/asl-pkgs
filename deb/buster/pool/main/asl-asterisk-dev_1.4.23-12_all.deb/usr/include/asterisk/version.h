/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT 3cbf9e7"
#define ASTERISK_VERSION_HTTP "AllStarClient/GIT 3cbf9e7"
#define ASTERISK_VERSION_NUM 

