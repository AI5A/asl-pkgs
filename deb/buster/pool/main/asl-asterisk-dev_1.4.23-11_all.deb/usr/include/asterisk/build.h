/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "fv-az340-548"
#define BUILD_KERNEL "5.15.0-1019-azure"
#define BUILD_MACHINE "armv7l"
#define BUILD_OS "Linux"
#define BUILD_DATE "2022-09-19 09:58:39 UTC"
#define BUILD_USER ""

