/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT eed0952"
#define ASTERISK_VERSION_HTTP "AllStarClient/GIT eed0952"
#define ASTERISK_VERSION_NUM 

