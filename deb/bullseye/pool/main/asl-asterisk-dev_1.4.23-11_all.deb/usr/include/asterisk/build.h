/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "fv-az550-353"
#define BUILD_KERNEL "5.15.0-1019-azure"
#define BUILD_MACHINE "armv7l"
#define BUILD_OS "Linux"
#define BUILD_DATE "2022-09-19 10:07:07 UTC"
#define BUILD_USER ""

