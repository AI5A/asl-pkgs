/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "GIT ca132e5"
#define ASTERISK_VERSION_HTTP "AllStarClient/GIT ca132e5"
#define ASTERISK_VERSION_NUM 

