/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "fv-az47-641"
#define BUILD_KERNEL "5.15.0-1019-azure"
#define BUILD_MACHINE "armv7l"
#define BUILD_OS "Linux"
#define BUILD_DATE "2022-09-10 06:37:44 UTC"
#define BUILD_USER ""

